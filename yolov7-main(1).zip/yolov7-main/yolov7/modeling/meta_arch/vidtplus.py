'''
https://github.com/naver-ai/vidt/tree/vidt-plus

swin-nano with mAP 45, while about 20FPS
'''
