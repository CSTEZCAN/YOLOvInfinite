from alfred.utils.log import logger

logger.info('this ia info')
logger.warning('this ia info')
logger.error('this ia info')