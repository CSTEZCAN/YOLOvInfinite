this folder contains new model design way in d2

